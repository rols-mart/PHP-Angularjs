var myApp = angular.module("myModule", []);

myApp.controller("myController", function ($scope) {
  $scope.message = "This is an AngularJS custom message";
});;
